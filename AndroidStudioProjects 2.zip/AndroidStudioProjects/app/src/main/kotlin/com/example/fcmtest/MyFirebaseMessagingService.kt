package com.example.fcmtest

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class MyFirebaseMessagingService : FirebaseMessagingService() {

    companion object {
        private const val CHANNEL_ID = "notification_channel"
        const val PREFS_NAME = "MyFirebaseMessagingService"
        const val KEY_TOKEN = "token"
        const val INTENT_FILTER = "INTENT_FILTER"
        const val MESSAGE_KEY = "MESSAGE_KEY"
    }

    override fun onNewToken(token: String) {
        Log.e("NEW_TOKEN", token)

        val sharedPreferences: SharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val editor: SharedPreferences.Editor = sharedPreferences.edit()
        editor.putString(KEY_TOKEN, token)
        editor.apply()
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)

        remoteMessage.notification?.let {
            Log.e("FCM Notification", "Title: ${it.title}, Body: ${it.body}")
            Log.e("FCM Data", remoteMessage.data.toString())

            val intent = Intent(INTENT_FILTER)
            intent.putExtra("title", it.title)
            intent.putExtra("body", it.body)
            LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
            sendNotification(it.title, it.body)
        }
    }

    private fun sendNotification(title: String?, messageBody: String?) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID,
                "Channel human readable title",
                NotificationManager.IMPORTANCE_DEFAULT)
            notificationManager.createNotificationChannel(channel)
        }

        val notificationBuilder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(messageBody)
            .setAutoCancel(true)

        notificationManager.notify(0 /* ID of notification */, notificationBuilder.build())
    }
}
